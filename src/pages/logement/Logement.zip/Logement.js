import React, { useEffect, useState } from "react";

import { useParams } from "react-router-dom";
import { getOneLogement } from "@/_services/api";
import Collapse from "@/components/collapse/Collapse";

import "./logement.css";

const Logement = () => {
  let { id } = useParams();
  const [logement, setLogement] = useState({});

  useEffect(() => {
    setLogement(getOneLogement(id));
    // eslint-disable-next-line
  }, []);

  const hostName = logement.host.name;

  console.log(hostName);

  return (
    <main className="Logement">
      <div className="logement-container">
        <div className="logement-infos">
          <div>
            <h2 className="logement-title">{logement.title}</h2>
            <p className="logement-location">{logement.location}</p>
          </div>
          <div className="logement-host">
            <p className="host-name">{hostName}</p>
            {/* <img src={logement.host.picture} alt="" /> */}
          </div>
          <div className="logement-tags">
            {/* {logement.tags.map((tag, i) => (
              <p key={i} className="tag">
                {tag}
              </p>
            ))} */}
          </div>
          <div className="rating"></div>
          <div className="logement-details">
            <Collapse title="Description" content={logement.description} />
            {/* <Collapse
              title="Équipements"
              content={logement.equipments.map((equipement, i) => (
                <p key={i}>{equipement}</p>
              ))}
            /> */}
          </div>
        </div>
      </div>
    </main>
  );
};

export default Logement;
